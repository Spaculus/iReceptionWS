﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class PropertyModel
    {
        public int ID { get; set; }
        public string custPID { get; set; }
        public string module { get; set; }
        public string type { get; set; }
        public string prop { get; set; }
        public string value { get; set; }
    }
}