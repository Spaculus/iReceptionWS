﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class UsersModel
    {
        public int ID { get; set; }
        public string pID { get; set; }
        public string customerPID { get; set; }
        public string name { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string username { get; set; }
        public string pincode { get; set; }
        public string reset_pincode { get; set; }
        public string admin { get; set; }
        public string systemuser { get; set; }
        public string status { get; set; }
        public int created { get; set; }
        public string formAction { get; set; }
        public string message { get; set; }
        public string issub { get; set; }
    }
}