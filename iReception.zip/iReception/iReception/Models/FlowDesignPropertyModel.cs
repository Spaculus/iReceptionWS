﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class FlowDesignPropertyModel
    {
        public string flow_designPID { get; set; }
        public string prop { get; set; }
        public string value { get; set; }
        public string ImageName { get; set; }

        //public virtual FlowDesignModel flow_designModel { get; set; }
    }
}