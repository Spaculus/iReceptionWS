﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class FlowEndUserModel
    {
        public int ID { get; set; }
        public string listPID { get; set; }
        public string userPID { get; set; }
        public Nullable<int> seq { get; set; }
        public string subUserPID { get; set; }
        public string page_headline { get; set; }
        public string page_subtext { get; set; }

        public virtual IEnumerable<UsersModel> UsersProperty { get; set; }
    }
}