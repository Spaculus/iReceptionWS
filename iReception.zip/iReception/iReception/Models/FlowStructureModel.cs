﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class FlowStructureModel
    {
        public int ID { get; set; }
        public string pID { get; set; }
        public string childPID { get; set; }
        public string sectionPID { get; set; }
        public string flowPID { get; set; }
        public string type { get; set; }
        public string itemname { get; set; }
        public string imagePID { get; set; }
        public string imageName { get; set; }
        public string targetPID { get; set; }
        public string startflag { get; set; }
        public string startflag_status { get; set; }
        public string startname { get; set; }
        public string entrykey { get; set; }
        public string design_key { get; set; }
        public string page_headline { get; set; }
        public string page_subtext { get; set; }
        public Nullable<int> seq { get; set; }
        public string root { get; set; }
        public Nullable<int> created { get; set; }
        public string issub { get; set; }
    }
}