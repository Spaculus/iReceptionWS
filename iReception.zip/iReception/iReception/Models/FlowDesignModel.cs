﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class FlowDesignModel
    {
        public int ID { get; set; }
        public string pID { get; set; }
        public string custPID { get; set; }
        public string name { get; set; }
        public string status { get; set; }
        public Nullable<int> modified { get; set; }
        public Nullable<int> created { get; set; }

        public virtual IEnumerable<FlowDesignPropertyModel> FlowDesignProperty { get; set; }
    }
}