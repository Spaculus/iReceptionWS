﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class WebApiParameters
    {
        public string logonkey { get; set; }
        public string flowPID { get; set; }
        public string childPID { get; set; }
        public string customerPID { get; set; }
        public string userPID { get; set; }
        public string listPID { get; set; }
        public string imagePID { get; set; }
        public string targetPID { get; set; }
        public string startflagPID { get; set; }

        public string userName { get; set; }
        public string userPhone { get; set; }
        public string userEmail { get; set; }
        public string userMessage { get; set; }
    }
}