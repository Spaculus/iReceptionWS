﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iReceptions.Models
{
    public class FlowModel
    {
        public int ID { get; set; }
        public string pID { get; set; }
        public string custPID { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string elem_position { get; set; }
        public string status { get; set; }
        public Nullable<int> modified { get; set; }
        public Nullable<int> created { get; set; }
        public string flowCount { get; set; }
    }
}