﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web.Http;
using iReception.Models;
using iReceptions.Models;

namespace iReception.Controllers
{
    public class ValuesController : ApiController
    {
        H7361_ireceptionEntities iReceptionsEntities = new H7361_ireceptionEntities();

        //// GET api/values
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/values/5
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/values
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT api/values/5
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE api/values/5
        //public void Delete(int id)
        //{
        //}

        [HttpGet]
        [ActionName("GetList")]
        public object GetList()
        {
            var result = iReceptionsEntities.users.Where(a => a.ID == 193).ToList();

            return new
            {
                Status = "Success",
                Result = result
            };
        }

        /// <summary>
        /// This Method used to get login detalis
        /// </summary>
        /// <param name="_userModel">Parameter :: logonkey = Property.value </param>
        /// <returns></returns>
        [ActionName("GetLogin"), HttpPost]
        public object GetLogin([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                var result = iReceptionsEntities.properties.Where(a => a.value == _webApiParameters.logonkey && a.prop == "module-setup-logonkey").ToList();

                var resultTimePeriod = iReceptionsEntities.properties.Where(a => a.prop == "system-default-msBeforeResetingToFrontpage"
                                                                            || a.prop == "system-default-msBeforeResetingtoFrontpageAtArrival"
                                                                            || a.prop == "system-default-msBeforeRestartingAfterReportingArrival").ToList();

                if (result.Count > 0)
                {
                    string custId = result.Select(b => b.custPID).FirstOrDefault();

                    var resultCalendar = iReceptionsEntities.properties.Where(a => (a.custPID == custId) && (a.module == "reception") && (a.prop == "module-setup-calendaraccount"
                                                                            || a.prop == "module-setup-calendarevent-timeafter"
                                                                            || a.prop == "module-setup-calendarevent-timebefore")).ToList();

                    return new
                    {
                        Status = "Success",
                        Result = result,
                        TimePeriod = resultTimePeriod,
                        CalendarProperty = resultCalendar
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "Please enter valid logon key"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get login details"
                };
            }
        }

        /// <summary>
        /// This method used to get users flow details
        /// </summary>
        /// <param name="_userModel">Parameter :: customerPID = Users.CustomerPID </param>
        /// <returns></returns>
        [ActionName("GetFlow"), HttpPost]
        public object GetFlow([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                //var result = iReceptionsEntities.flows.Where(a => a.custPID == _userModel.customerPID && a.status == "Aktiv").ToList(); // Old Line working with Flow Count

                var result = (from flowEntity in iReceptionsEntities.flows
                              where flowEntity.custPID == _webApiParameters.customerPID && flowEntity.status == "Aktiv"
                              select new
                              {
                                  ID = flowEntity.ID,
                                  pID = flowEntity.pID,
                                  custPID = flowEntity.custPID,
                                  name = flowEntity.name,
                                  description = flowEntity.description,
                                  elem_position = flowEntity.elem_position,
                                  status = flowEntity.status,
                                  modified = flowEntity.modified,
                                  created = flowEntity.created,
                                  flowCount = iReceptionsEntities.flowstructures.Count(a => a.flowPID == flowEntity.pID && a.startflag == "Y" && a.startflag_status == "Aktiv")
                              }).AsEnumerable().Select(x => new FlowModel
                              {
                                  ID = x.ID,
                                  pID = x.pID,
                                  custPID = x.custPID,
                                  name = x.name,
                                  description = x.description,
                                  elem_position = x.elem_position,
                                  status = x.status,
                                  modified = x.modified,
                                  created = x.created,
                                  flowCount = x.flowCount.ToString()
                              }).ToList();

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No Flow found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get flow details, please contact administrator"
                };
            }
        }

        /// <summary>
        /// This method used to get users flow entry key details
        /// </summary>
        /// <param name="_userModel">Parameter :: flowPID = Flow.PID </param>
        /// <returns></returns>
        [ActionName("GetFlowEntryKey"), HttpPost]
        public object GetFlowEntryKey([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                var result = iReceptionsEntities.flowstructures.Where(a => a.flowPID == _webApiParameters.flowPID
                                                                && a.entrykey != null && a.startflag == "Y" && a.startflag_status == "Aktiv")
                                                                .OrderBy(a => a.seq).ToList();

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No Flow Entry key found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get flow entry key details, please contact administrator"
                };
            }
        }

        /// <summary>
        /// This method used to get Flow structure details
        /// </summary>
        /// <param name="_flowModel">Parameter :: flowPID = Flows.PID, childPID = Flows.CustPID </param>
        /// <returns></returns>
        [ActionName("GetFlowStructureById"), HttpPost]
        public object GetFlowStructureById([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                //var result = iReceptionsEntities.flowstructures.Where(a => a.flowPID == _webApiParameters.flowPID
                //                                                && (_webApiParameters.childPID == null ? a.childPID == null : a.childPID == _webApiParameters.childPID))
                //                                                .OrderBy(a => a.seq).ToList();

                var resultDesign = GetDesignDetails(_webApiParameters.customerPID);

                var designKey = iReceptionsEntities.flowstructures.Where(a => a.flowPID == _webApiParameters.flowPID && a.pID == _webApiParameters.startflagPID
                                                                && a.entrykey != null && a.startflag == "Y" && a.startflag_status == "Aktiv")
                                                                .Select(a => a.design_key).FirstOrDefault();

                var rParent = (from flStru in iReceptionsEntities.flowstructures
                               where flStru.flowPID == _webApiParameters.flowPID &&
                               (_webApiParameters.childPID == null ? flStru.childPID == null : flStru.pID == _webApiParameters.childPID)
                               select flStru).FirstOrDefault();

                string parentTitle = rParent != null ? rParent.page_headline : "";

                var result = (from flStru in iReceptionsEntities.flowstructures
                              where flStru.flowPID == _webApiParameters.flowPID &&
                              (_webApiParameters.childPID == null ? flStru.childPID == null : flStru.childPID == _webApiParameters.childPID)
                              orderby flStru.seq
                              select new
                              {
                                  flowStruc = flStru
                              }).AsEnumerable().Select(x => new FlowStructureModel
                              {
                                  ID = x.flowStruc.ID,
                                  pID = x.flowStruc.pID,
                                  childPID = x.flowStruc.childPID,
                                  sectionPID = x.flowStruc.sectionPID,
                                  flowPID = x.flowStruc.flowPID,
                                  type = x.flowStruc.type,
                                  itemname = x.flowStruc.itemname,
                                  imagePID = x.flowStruc.imagePID,
                                  imageName = iReceptionsEntities.images.Where(b => b.pID == x.flowStruc.imagePID).Select(c => c.filename).FirstOrDefault(),
                                  targetPID = x.flowStruc.targetPID,
                                  startflag = x.flowStruc.startflag,
                                  startflag_status = x.flowStruc.startflag_status,
                                  startname = x.flowStruc.startname,
                                  entrykey = x.flowStruc.entrykey,
                                  design_key = x.flowStruc.design_key,
                                  page_headline = x.flowStruc.page_headline,
                                  page_subtext = x.flowStruc.page_subtext,
                                  seq = x.flowStruc.seq,
                                  root = x.flowStruc.root,
                                  created = x.flowStruc.created,
                                  issub = (iReceptionsEntities.flowstructures.Where(a => x.flowStruc.pID == a.childPID).Count() > 0) ? "yes" : "no"
                              }).ToList();

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result,
                        Design = resultDesign,
                        PageTitle = parentTitle,
                        DesignKey = designKey
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No Flow structure found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get flow structure details, please contact administrator"
                };
            }
        }

        /// <summary>
        /// This Method used to Get Flow End Users List details
        /// </summary>
        /// <param name="FlowEndUserModel">Parameter :: listPID = FlowEndUser.listPID</param>
        /// <returns></returns>
        [ActionName("GetFlowEndUsersList"), HttpPost]
        public object GetFlowEndUsersList([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                var designKey = iReceptionsEntities.flowstructures.Where(a => a.pID == _webApiParameters.startflagPID
                                                                && a.entrykey != null && a.startflag == "Y" && a.startflag_status == "Aktiv")
                                                                .Select(a => a.design_key).FirstOrDefault();

                var vOrder = iReceptionsEntities.flowenduser_list.Where(a => a.pID == _webApiParameters.targetPID && a.customerPID == _webApiParameters.customerPID)
                                                .Select(a => a.sort_by).FirstOrDefault();

                var resultDesign = GetDesignDetails(_webApiParameters.customerPID);

                var result = (from flowUserList in iReceptionsEntities.flowenduser_list
                              where flowUserList.pID == _webApiParameters.targetPID
                              select new
                              {
                                  flowUserList = flowUserList
                              }).AsEnumerable().Select(x => new FlowEndUserListModel
                              {

                                  pID = x.flowUserList.pID,
                                  customerPID = x.flowUserList.customerPID,
                                  listname = x.flowUserList.listname,
                                  check_unplanned = x.flowUserList.check_unplanned,
                                  sort_by = x.flowUserList.sort_by,
                                  page_headline = x.flowUserList.page_headline,
                                  page_subtext = x.flowUserList.page_subtext,
                                  created = x.flowUserList.created,
                                  UsersProperty = GetUserProperty(x.flowUserList.pID, vOrder)
                              }).ToList();

                //if (vOrder != null)
                //{
                //    if (vOrder == "bySeq")
                //    {
                //        result = result.OrderBy(a => a.sort_by).ToList();
                //    }
                //}

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result,
                        Design = resultDesign,
                        DesignKey = designKey
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No Flow End User List found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get flow End User List details, please contact administrator"
                };
            }
        }

        /// <summary>
        /// This Method used to Get Flow End Users details
        /// </summary>
        /// <param name="_userModel">Parameter :: pID = Users.PID</param>
        /// <returns></returns>
        [ActionName("GetFlowEndUsers"), HttpPost]
        public object GetFlowEndUsers([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                var designKey = iReceptionsEntities.flowstructures.Where(a => a.pID == _webApiParameters.startflagPID
                                                                && a.entrykey != null && a.startflag == "Y" && a.startflag_status == "Aktiv")
                                                                .Select(a => a.design_key).FirstOrDefault();

                var vOrder = iReceptionsEntities.flowenduser_list.Where(a => a.pID == _webApiParameters.targetPID && a.customerPID == _webApiParameters.customerPID)
                                                .Select(a => a.sort_by).FirstOrDefault();

                var result = (from flowUser in iReceptionsEntities.flowendusers
                              where flowUser.listPID == _webApiParameters.targetPID && flowUser.userPID == _webApiParameters.userPID
                              select new
                              {
                                  flowUser = flowUser
                              }).AsEnumerable().Select(x => new FlowEndUserModel
                              {
                                  ID = x.flowUser.ID,
                                  listPID = x.flowUser.listPID,
                                  userPID = x.flowUser.userPID,
                                  seq = x.flowUser.seq,
                                  subUserPID = x.flowUser.subUserPID,
                                  page_headline = x.flowUser.page_headline, //.Replace("{bruger}", (iReceptionsEntities.flowenduser_list.Where(a => a.pID == x.flowUser.listPID).Select(a => a.listname).FirstOrDefault())),
                                  page_subtext = x.flowUser.page_subtext,
                                  UsersProperty = GetUserListProperty(x.flowUser.subUserPID, vOrder)
                              }).ToList();

                if (vOrder != null)
                {
                    if (vOrder == "bySeq")
                    {
                        result = result.OrderBy(a => a.seq).ToList();
                    }
                }

                var resultDesign = GetDesignDetails(_webApiParameters.customerPID);

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result,
                        Design = resultDesign,
                        DesignKey = designKey
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No Flow End User found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get flow End User details, please contact administrator"
                };
            }
        }

        /// <summary>
        /// This Method used to Get Flow Design List with flow design property details
        /// </summary>
        /// <param name="FlowEndUserModel">Parameter :: customerPID = Users.CustomerID</param>
        /// <returns></returns>
        [ActionName("GetFlowDesign"), HttpPost]
        public object GetFlowDesign([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                //var result = iReceptionsEntities.flow_design.Where(a => a.custPID == _webApiParameters.customerPID).ToList();

                var result = (from flowD in iReceptionsEntities.flow_design
                              where flowD.custPID == _webApiParameters.customerPID
                              select new
                              {
                                  flowDesign = flowD
                              }).AsEnumerable().Select(x => new FlowDesignModel
                              {
                                  ID = x.flowDesign.ID,
                                  pID = x.flowDesign.pID,
                                  custPID = x.flowDesign.custPID,
                                  name = x.flowDesign.name,
                                  status = x.flowDesign.status,
                                  modified = x.flowDesign.modified,
                                  created = x.flowDesign.created,
                                  FlowDesignProperty = GetDesignProperty(x.flowDesign.pID)
                              }).ToList();

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No Flow Design found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get flow design details, please contact administrator"
                };
            }
        }

        /// <summary>
        /// This Method used to Get Flow End Users List details
        /// </summary>
        /// <param name="FlowEndUserModel">Parameter :: listPID = FlowEndUser.listPID</param>
        /// <returns></returns>
        [ActionName("GetUserPropertyByUserId"), HttpPost]
        public object GetUserPropertyByUserId([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                var result = iReceptionsEntities.user_property.Where(a => a.userPID == _webApiParameters.userPID).ToList();

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No User Property List found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get user property list details, please contact administrator"
                };
            }
        }

        /// <summary>
        /// This Method used to Get Flow End Users List details
        /// </summary>
        /// <param name="FlowEndUserModel">Parameter :: listPID = FlowEndUser.listPID</param>
        /// <returns></returns>
        [ActionName("GetImagesById"), HttpPost]
        public object GetImagesById([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                var result = iReceptionsEntities.images.Where(a => a.pID == _webApiParameters.imagePID &&
                                                             a.custPID == _webApiParameters.customerPID && a.status == "Aktiv").ToList();

                if (result.Count > 0)
                {
                    return new
                    {
                        Status = "Success",
                        Result = result
                    };
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "No Images List found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get images list details, please contact administrator"
                };
            }
        }

        [ActionName("SendNotification"), HttpPost]
        public object SendNotification([FromBody] WebApiParameters _webApiParameters)
        {
            try
            {
                //Get User Data -- Name, Email, phone
                //Get User Property to check Email & SMS Notification
                //Get property By Customer PID

                TimeSpan span = DateTime.Now.Subtract(new DateTime(1980, 1, 1, 0, 0, 0, DateTimeKind.Utc));
                int logtime = Convert.ToInt32(span.TotalSeconds);

                var resultUser = iReceptionsEntities.users.Where(a => a.pID == _webApiParameters.userPID).FirstOrDefault();

                if (resultUser != null)
                {
                    var resultUserProperty = iReceptionsEntities.user_property.Where(a => a.userPID == _webApiParameters.userPID).ToList();
                    bool isFormula = false;

                    if (resultUserProperty.Count > 0)
                    {
                        string[] sEmailList = resultUser.email.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        string[] sPhoneList = resultUser.phone.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                        var isPopupType = resultUserProperty.Where(a => a.prop == "unplanned_action").FirstOrDefault();
                        var isSendEmail = resultUserProperty.Where(a => a.prop == "use_email" && a.value == "Y").ToList();
                        var isSendSMS = resultUserProperty.Where(a => a.prop == "use_phone" && a.value == "Y").ToList();

                        var resultProperty = iReceptionsEntities.properties.Where(a => a.custPID == _webApiParameters.customerPID).ToList();

                        //below try catch used to send email notification.
                        try
                        {
                            if (isPopupType.value == "default")
                            {
                                if (isSendEmail.Count > 0)
                                {
                                    var fromEmailAddress = resultProperty.Where(a => a.prop == "module-setup-emailaddress").Select(a => a.value).FirstOrDefault();
                                    var emailSubject = resultProperty.Where(a => a.prop == "module-setup-emailcarriername").Select(a => a.value).FirstOrDefault();
                                    var emailBody = resultProperty.Where(a => a.prop == "module-setup-emailsubject").Select(a => a.value).FirstOrDefault();

                                    emailBody = emailBody.Replace("{navn}", _webApiParameters.userName);

                                    //SendMail(fromEmailAddress, resultUser.email, emailSubject, emailBody);
                                    //InsertEventLog(_webApiParameters.customerPID, _webApiParameters.userPID, logtime, "SendOutArrival", "Email");

                                    for (int i = 0; i < sEmailList.Length; i++)
                                    {
                                        //SendMail(fromEmailAddress, sEmailList[i].Trim(), emailSubject, emailBody);
                                        SendMailDefault(fromEmailAddress, sEmailList[i].Trim(), emailSubject, emailBody);
                                    }

                                    InsertEventLog(_webApiParameters.customerPID, _webApiParameters.userPID, logtime, "SendOutArrival", "Email");
                                }
                            }
                            else if (isPopupType.value == "formula")
                            {
                                isFormula = true;

                                if (isSendEmail.Count > 0)
                                {
                                    var fromEmail = iReceptionsEntities.properties.Where(a => a.prop == "system-default-noreply-emailaddress").Select(a => a.value).FirstOrDefault();

                                    string sBody = string.Empty;
                                    sBody = "Følgende person har sendt denne besked.<br/><br/>" +
                                                    "<b>Navn: </b>" + _webApiParameters.userName + "<br/>" +
                                                    "<b>Telefon nr.: </b>" + _webApiParameters.userPhone + "<br/>" +
                                                    "<b>Email: </b>" + _webApiParameters.userEmail + "<br/>" +
                                                    "<b>Besked: </b><br/>" + _webApiParameters.userMessage + "";

                                    //SendMail(fromEmail, resultUser.email, "Besked fra iRECEPTION.", sBody);
                                    //InsertEventLog(_webApiParameters.customerPID, _webApiParameters.userPID, logtime, "SendOutArrival", "Email");

                                    for (int i = 0; i < sEmailList.Length; i++)
                                    {
                                        SendMail(fromEmail, sEmailList[i].Trim(), "Besked fra iRECEPTION.", sBody);
                                    }

                                    InsertEventLog(_webApiParameters.customerPID, _webApiParameters.userPID, logtime, "SendOutArrival", "Email");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                        }

                        //below try catch used to send SMS notification
                        try
                        {
                            if (!isFormula)
                            {
                                if (isSendSMS.Count > 0)
                                {
                                    var fromSmsGatewayEmail = resultProperty.Where(a => a.prop == "module-setup-smsgatewayemail").Select(a => a.value).FirstOrDefault();
                                    var smsEmailCode = resultProperty.Where(a => a.prop == "module-setup-smsgatewayemailcode").Select(a => a.value).FirstOrDefault();
                                    var smsSubject = resultProperty.Where(a => a.prop == "module-setup-smscarriername").Select(a => a.value).FirstOrDefault();
                                    var smsBody = resultProperty.Where(a => a.prop == "module-setup-smsbody").Select(a => a.value).FirstOrDefault();
                                    smsBody = smsBody.Replace("{navn}", _webApiParameters.userName);

                                    if (!string.IsNullOrEmpty(_webApiParameters.userPhone))
                                    {
                                        smsBody = smsBody + "  Svar personen evt. via sms ved at klikke her sms:" + _webApiParameters.userPhone;
                                    }

                                    //string recieverEmail = "45" + resultUser.phone + "." + smsEmailCode + "@cpsms.dk";

                                    //SendMail(fromSmsGatewayEmail, recieverEmail, smsSubject, smsBody);
                                    //InsertEventLog(_webApiParameters.customerPID, _webApiParameters.userPID, logtime, "SendOutArrival", "SMS");

                                    string recieverEmail = string.Empty;

                                    for (int i = 0; i < sPhoneList.Length; i++)
                                    {
                                        recieverEmail = "45" + sPhoneList[i].Trim() + "." + smsEmailCode + "@cpsms.dk";
                                        SendMail(fromSmsGatewayEmail, recieverEmail, smsSubject, smsBody);
                                    }

                                    InsertEventLog(_webApiParameters.customerPID, _webApiParameters.userPID, logtime, "SendOutArrival", "SMS");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                        }

                        return new
                        {
                            Status = "Success",
                            Result = "Email sent sucessfully"
                        };
                    }
                    else
                    {
                        return new
                        {
                            Status = "Fail",
                            Result = "User property not found"
                        };
                    }
                }
                else
                {
                    return new
                    {
                        Status = "Fail",
                        Result = "User details not found"
                    };
                }
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in get images list details, please contact administrator"
                };
            }
        }

        [ActionName("Signup"), HttpPost]
        public object Signup([FromBody] customer _customer)
        {
            try
            {
                string pID = GenerateCustomerPID(DateTime.Now.ToString());
                TimeSpan span = DateTime.Now.Subtract(new DateTime(1980, 1, 1, 0, 0, 0, DateTimeKind.Utc));
                int logtime = Convert.ToInt32(span.TotalSeconds);

                _customer.pID = pID;
                _customer.deactivated = "N";
                _customer.status = "OK";
                _customer.created = logtime;

                iReceptionsEntities.customers.Add(_customer);
                iReceptionsEntities.SaveChanges();

                try
                {
                    var fromEmail = iReceptionsEntities.properties.Where(a => a.prop == "system-default-noreply-emailaddress").Select(a => a.value).FirstOrDefault();

                    string sBody = string.Empty;
                    sBody = "<b>Firmanavn: </b>" + _customer.companyname + "<br/>" +
                            "<b>Kontaktname: </b>" + _customer.contactname + "<br/>" +
                            "<b>Adresse: </b>" + _customer.address + "<br/>" +
                            "<b>Post nr.: </b>" + _customer.zipcode + "<br/>" +
                            "<b>By: </b>" + _customer.city + "<br/>" +
                            "<b>Telefon nr.: </b>" + _customer.phone + "<br/>" +
                            "<b>E-mail: </b>" + _customer.email + "<br/>";

                    SendMailDefault(fromEmail, "support@ireception.dk", "iReception", "Ny registrering fra app", sBody);
                }
                catch (Exception ex)
                {
                }

                return new
                {
                    Status = "Success",
                    Result = "Data inserted successfully"
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    Status = "Error",
                    Result = "Error in sign up, please contact administrator"
                };
            }
        }

        public List<FlowDesignPropertyModel> GetDesignProperty(string flowDesignPID)
        {
            List<FlowDesignPropertyModel> listFlowDP = new List<FlowDesignPropertyModel>();

            try
            {
                var result = (from fldp in iReceptionsEntities.flow_design_property
                              where fldp.flow_designPID == flowDesignPID
                              select new FlowDesignPropertyModel
                              {
                                  flow_designPID = fldp.flow_designPID,
                                  prop = fldp.prop,
                                  value = fldp.value.Replace("rgba(", string.Empty).Replace(")", string.Empty),
                                  ImageName = iReceptionsEntities.images.Where(a => a.pID == fldp.value).Select(a => a.filename).FirstOrDefault()
                              }).ToList();

                listFlowDP = result;
            }
            catch (Exception ex)
            {
            }

            return listFlowDP;
        }

        public List<UsersModel> GetUserProperty(string flowTargetPID, string vOrderBy)
        {
            List<UsersModel> listUsersModel = new List<UsersModel>();

            try
            {
                var result = (from flUsers in iReceptionsEntities.flowendusers
                              join users in iReceptionsEntities.users on flUsers.userPID equals users.pID
                              where flUsers.listPID == flowTargetPID
                              orderby flUsers.seq
                              select new UsersModel
                              {
                                  ID = users.ID,
                                  pID = users.pID,
                                  customerPID = users.customerPID,
                                  name = users.name,
                                  phone = users.phone,
                                  email = users.email,
                                  username = users.username,
                                  pincode = users.pincode,
                                  reset_pincode = users.reset_pincode,
                                  admin = users.admin,
                                  systemuser = users.systemuser,
                                  status = users.status,
                                  created = users.created,
                                  issub = flUsers.subUserPID != null ? "yes" : "no",
                                  formAction = iReceptionsEntities.user_property.Where(a => a.userPID == users.pID && a.prop == "unplanned_action").Select(a => a.value).FirstOrDefault(),
                                  message = iReceptionsEntities.user_property.Where(a => a.userPID == users.pID && a.prop == "message").Select(a => a.value).FirstOrDefault(),
                              }).ToList();

                if (vOrderBy == "byAlphabet")
                {
                    result = result.OrderBy(a => a.name).ToList();
                }

                listUsersModel = result;
            }
            catch (Exception ex)
            {
            }

            return listUsersModel;
        }

        public List<UsersModel> GetUserListProperty(string subUserList, string vOrderBy)
        {
            List<UsersModel> listUsersModel = new List<UsersModel>();
            string[] stUsers = subUserList.Split(',');

            try
            {
                var result = (from users in iReceptionsEntities.users
                              where stUsers.Contains(users.pID)
                              select new UsersModel
                              {
                                  ID = users.ID,
                                  pID = users.pID,
                                  customerPID = users.customerPID,
                                  name = users.name,
                                  phone = users.phone,
                                  email = users.email,
                                  username = users.username,
                                  pincode = users.pincode,
                                  reset_pincode = users.reset_pincode,
                                  admin = users.admin,
                                  systemuser = users.systemuser,
                                  status = users.status,
                                  created = users.created,
                                  formAction = iReceptionsEntities.user_property.Where(a => a.userPID == users.pID && a.prop == "unplanned_action").Select(a => a.value).FirstOrDefault(),
                                  message = iReceptionsEntities.user_property.Where(a => a.userPID == users.pID && a.prop == "message").Select(a => a.value).FirstOrDefault(),
                              }).ToList();

                if (vOrderBy == "byAlphabet")
                {
                    result = result.OrderBy(a => a.name).ToList();
                }

                listUsersModel = result;
            }
            catch (Exception ex)
            {
            }

            return listUsersModel;
        }

        private List<FlowDesignModel> GetDesignDetails(string customerPID)
        {
            var resultDesign = (from flowD in iReceptionsEntities.flow_design
                                where flowD.custPID == customerPID
                                select new
                                {
                                    flowDesign = flowD
                                }).AsEnumerable().Select(x => new FlowDesignModel
                                {
                                    ID = x.flowDesign.ID,
                                    pID = x.flowDesign.pID,
                                    custPID = x.flowDesign.custPID,
                                    name = x.flowDesign.name,
                                    status = x.flowDesign.status,
                                    modified = x.flowDesign.modified,
                                    created = x.flowDesign.created,
                                    FlowDesignProperty = GetDesignProperty(x.flowDesign.pID)
                                }).ToList();

            return resultDesign;
        }

        private void SendMailDefault(string sFromAddress, string sToAddress, string sName, string sSubject, string sBody = "")
        {
            try
            {
                SmtpClient mailClient = new SmtpClient("small.massmail.scannet.dk");

                MailAddress fromAddress = new MailAddress(sFromAddress, sName);
                MailAddress toAddress = new MailAddress(sToAddress);
                MailMessage message = new MailMessage(fromAddress, toAddress);

                message.Subject = sSubject;
                message.Body = sBody;
                message.IsBodyHtml = true;

                mailClient.Send(message);
            }
            catch (Exception ex)
            {
            }
        }

        private void SendMail(string sFromAddress, string sToAddress, string sSubject, string sBody)
        {
            try
            {
                SmtpClient mailClient = new SmtpClient("small.massmail.scannet.dk");

                MailMessage message = new MailMessage(sFromAddress, sToAddress);
                message.Subject = sSubject;
                message.Body = sBody;
                message.IsBodyHtml = true;

                mailClient.Send(message);
            }
            catch (Exception ex)
            {
            }
        }

        private void InsertEventLog(string custPID, string userPID, int logTime, string type, string prop)
        {
            try
            {
                eventlog _eventLog = new eventlog();
                _eventLog.custPID = custPID;
                _eventLog.userPID = userPID;
                _eventLog.logtime = logTime;
                _eventLog.module = "Reception";
                _eventLog.type = type;
                _eventLog.prop = prop;
                _eventLog.value = "True";

                iReceptionsEntities.eventlogs.Add(_eventLog);
                iReceptionsEntities.SaveChanges();
            }
            catch (Exception ex)
            {
            }
        }

        public string GenerateCustomerPID(string phrase)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            SHA256Managed sha256hasher = new SHA256Managed();
            byte[] hashedDataBytes = sha256hasher.ComputeHash(encoder.GetBytes(phrase));            
            string sPidEncrpyt = Convert.ToBase64String(hashedDataBytes);

            string sPid = System.Text.RegularExpressions.Regex.Replace(sPidEncrpyt, "[^a-zA-Z0-9]+", "", System.Text.RegularExpressions.RegexOptions.Compiled);            
            //sPid = sPid.Replace("+", string.Empty).Replace("/", string.Empty).Substring(0, 10);
            sPid = sPid.Substring(0, 10);

            var cntRecord = iReceptionsEntities.customers.Where(a => a.pID == sPid).Count();

            if (cntRecord == 0)
            {
                return sPid;
            }
            else
            {
                return GenerateCustomerPID(DateTime.Now.ToString());
            }
        }

        #region Comment Code

        //[ActionName("GetAllCalendarItems"), HttpGet]
        //public void GetAllCalendarItems()
        //{
        //    Microsoft.Office.Interop.Outlook.Application oApp = null;
        //    Microsoft.Office.Interop.Outlook.NameSpace mapiNamespace = null;
        //    Microsoft.Office.Interop.Outlook.MAPIFolder CalendarFolder = null;
        //    Microsoft.Office.Interop.Outlook.Items outlookCalendarItems = null;

        //    oApp = new Microsoft.Office.Interop.Outlook.Application();
        //    mapiNamespace = oApp.GetNamespace("MAPI"); ;
        //    CalendarFolder = mapiNamespace.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderCalendar); outlookCalendarItems = CalendarFolder.Items;
        //    outlookCalendarItems.IncludeRecurrences = true;

        //    foreach (Microsoft.Office.Interop.Outlook.AppointmentItem item in outlookCalendarItems)
        //    {
        //        //if (item.IsRecurring)
        //        //{
        //        Microsoft.Office.Interop.Outlook.RecurrencePattern rp = item.GetRecurrencePattern();
        //        DateTime first = new DateTime(2008, 8, 31, item.Start.Hour, item.Start.Minute, 0);
        //        DateTime last = new DateTime(2008, 10, 1);
        //        Microsoft.Office.Interop.Outlook.AppointmentItem recur = null;

        //        for (DateTime cur = first; cur <= last; cur = cur.AddDays(1))
        //        {
        //            try
        //            {
        //                recur = rp.GetOccurrence(cur);
        //            }
        //            catch
        //            { }
        //        }
        //        //}
        //        //else
        //        //{
        //        //}
        //    }

        //}

        //var result2 = (from x in iReceptionsEntities.flow_design
        //              where x.custPID == _webApiParameters.customerPID
        //              select new
        //              {
        //                ID = x.ID,
        //                pID = x.pID,
        //                custPID = x.custPID,
        //                name = x.name,
        //                status = x.status,
        //                modified = x.modified,
        //                created = x.created,
        //                flow_design_propertyModel =  (from fldp in iReceptionsEntities.flow_design_property
        //                                             where fldp.flow_designPID == x.pID
        //                                             select new FlowDesignPropertyModel
        //                                             {
        //                                                 flow_designPID = fldp.flow_designPID,
        //                                                 prop = fldp.prop,
        //                                                 value = fldp.value
        //                                             }).ToList()
        //            }).ToList();



        // Below is working
        //var result1 = (from flowD in iReceptionsEntities.flow_design
        //              //join flowDP in iReceptionsEntities.flow_design_property on flowD.pID equals flowDP.flow_designPID into grpFDP
        //              //from flowDProperty in grpFDP.DefaultIfEmpty()
        //              where flowD.custPID == _webApiParameters.customerPID
        //              select new
        //              {
        //                  flowDesign = flowD,
        //                  //flowDesignProperty = (from fldp in iReceptionsEntities.flow_design_property
        //                  //                      where fldp.flow_designPID == flowD.pID
        //                  //                      select new
        //                  //                      {
        //                  //                          flowdp = fldp
        //                  //                      }).AsEnumerable().Select(p => new FlowDesignPropertyModel()
        //                  //                      {
        //                  //                          flow_designPID = p.flowdp.flow_designPID,
        //                  //                          prop = p.flowdp.prop,
        //                  //                          value = p.flowdp.value
        //                  //                      })
        //                  flowDesignProperty = (from fldp in iReceptionsEntities.flow_design_property
        //                                               where fldp.flow_designPID == flowD.pID
        //                                               select new FlowDesignPropertyModel
        //                                               {
        //                                                   flow_designPID = fldp.flow_designPID,
        //                                                   prop = fldp.prop,
        //                                                   value = fldp.value
        //                                               })
        //              }).AsEnumerable().Select(x => new FlowDesignModel
        //              {
        //                  ID = x.flowDesign.ID,
        //                  pID = x.flowDesign.pID,
        //                  custPID = x.flowDesign.custPID,
        //                  name = x.flowDesign.name,
        //                  status = x.flowDesign.status,
        //                  modified = x.flowDesign.modified,
        //                  created = x.flowDesign.created,
        //                  flow_design_propertyModel = x.flowDesignProperty.ToList()
        //              }).ToList();
        #endregion
    }
}